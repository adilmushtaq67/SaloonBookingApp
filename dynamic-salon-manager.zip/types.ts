
export type Role = 'customer' | 'admin';

export interface Service {
  id: string;
  name: string;
  duration: number; // in minutes
  price: number;
  description: string;
}

export interface Booking {
  id: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  serviceId: string;
  serviceName: string;
  price?: number; // Snapshot of price at booking time
  date: string; // YYYY-MM-DD
  timeSlot: string; // HH:mm
  status: 'confirmed' | 'cancelled' | 'completed';
  paymentStatus: 'paid' | 'pending' | 'refunded';
  transactionId?: string;
  notes?: string;
  createdAt: string;
  remindersSent?: {
    h24: boolean;
    h1: boolean;
  };
}

export interface WaitlistEntry {
  id: string;
  email: string;
  date: string;
  createdAt: string;
}

export interface SalonConfig {
  openTime: string; // HH:mm
  closeTime: string; // HH:mm
  holidays: string[]; // YYYY-MM-DD
  slotInterval: number; // in minutes, usually 60
  emailSettings: {
    provider: 'simulated' | 'gmail';
    gmailAddress: string;
    gmailAppPassword?: string;
    gmailAccessToken?: string; // OAuth2 Access Token for API
  };
}

export interface TimeSlot {
  time: string;
  status: 'available' | 'booked' | 'blocked' | 'past';
  bookingId?: string;
}

export interface Notification {
  id: string;
  recipient: string;
  sender?: string;
  type: 'confirmation' | 'reminder' | 'availability';
  message: string;
  timestamp: string;
  read: boolean;
  deliveryMethod: 'simulated' | 'gmail';
}

export interface CustomerPreferences {
  receiveConfirmations: boolean;
  receiveReminders: boolean;
}

export const DEFAULT_SERVICES: Service[] = [
  { id: '1', name: 'Signature Haircut', duration: 60, price: 85, description: 'Wash, cut, and blow-dry styling.' },
  { id: '2', name: 'Balayage Color', duration: 180, price: 250, description: 'Hand-painted highlights for a natural look.' },
  { id: '3', name: 'Express Facial', duration: 30, price: 60, description: 'Quick refreshing facial treatment.' },
  { id: '4', name: 'Gel Manicure', duration: 60, price: 55, description: 'Long-lasting gel polish application.' },
];

export const DEFAULT_CONFIG: SalonConfig = {
  openTime: '09:00',
  closeTime: '18:00',
  holidays: [],
  slotInterval: 60,
  emailSettings: {
    provider: 'gmail',
    gmailAddress: 'adil.mushtaq67@gmail.com',
    gmailAppPassword: '',
    gmailAccessToken: ''
  }
};

export const DEFAULT_CUSTOMER_PREFS: CustomerPreferences = {
  receiveConfirmations: true,
  receiveReminders: true
};
