import { GoogleGenAI } from "@google/genai";
import { Service, Booking, TimeSlot } from "../types";

// Helper to safely get API key
const getApiKey = (): string | undefined => {
  // Check if process is defined to avoid ReferenceError in browser environments
  if (typeof process !== 'undefined' && process.env) {
    return process.env.API_KEY;
  }
  return undefined;
};

export const generateAIResponse = async (
  userMessage: string,
  contextData: { services: Service[], todaySlots?: TimeSlot[] }
): Promise<string> => {
  const apiKey = getApiKey();
  if (!apiKey) {
    return "I'm sorry, I'm currently offline (API Key missing). Please call the salon directly.";
  }

  const ai = new GoogleGenAI({ apiKey });

  const systemInstruction = `
    You are 'Lumi', the intelligent virtual receptionist for Lumière Salon.
    
    Your goal is to assist customers with:
    1. Choosing a service based on their needs.
    2. Checking availability (based on provided context).
    3. Answering questions about pricing and duration.
    
    Tone: Professional, warm, chic, and concise.
    
    Current Services Offered:
    ${JSON.stringify(contextData.services)}
    
    Availability for Today (if asked):
    ${contextData.todaySlots ? JSON.stringify(contextData.todaySlots.filter(s => s.status === 'available')) : "Ask user to select a date first."}
    
    Rules:
    - If a user asks to book, guide them to use the calendar form on the screen.
    - Keep answers short (under 50 words unless detail is requested).
    - Do NOT make up services not in the list.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userMessage,
      config: {
        systemInstruction: systemInstruction,
      },
    });

    return response.text || "I apologize, I didn't catch that. Could you rephrase?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to my brain right now. Please try again later.";
  }
};