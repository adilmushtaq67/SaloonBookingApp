
import { Booking, SalonConfig, Service, Notification, WaitlistEntry, CustomerPreferences, DEFAULT_SERVICES, DEFAULT_CONFIG, DEFAULT_CUSTOMER_PREFS } from '../types';

const KEYS = {
  BOOKINGS: 'lumiere_bookings',
  CONFIG: 'lumiere_config',
  SERVICES: 'lumiere_services',
  NOTIFICATIONS: 'lumiere_notifications',
  WAITLIST: 'lumiere_waitlist',
  CUSTOMER_PREFS: 'lumiere_customer_prefs',
  ADMIN_SESSION: 'lumiere_admin_session'
};

// Helper for generating IDs safely
const generateId = (): string => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// --- Auth ---
export const validateAdminCredentials = (email: string, pass: string): boolean => {
  // Hardcoded secure credentials as requested
  // In a real backend, this would check a database hash
  return email === 'adil.mushtaq67@gmail.com' && pass === 'admin123';
};

export const setAdminSession = (isValid: boolean) => {
  if (isValid) {
    localStorage.setItem(KEYS.ADMIN_SESSION, 'true');
  } else {
    localStorage.removeItem(KEYS.ADMIN_SESSION);
  }
};

export const checkAdminSession = (): boolean => {
  return localStorage.getItem(KEYS.ADMIN_SESSION) === 'true';
};

// --- Config ---
export const getConfig = (): SalonConfig => {
  const stored = localStorage.getItem(KEYS.CONFIG);
  if (!stored) return DEFAULT_CONFIG;
  
  const config = JSON.parse(stored);
  // Merge with default to ensure new fields like emailSettings exist if old config is stored
  return { ...DEFAULT_CONFIG, ...config, emailSettings: { ...DEFAULT_CONFIG.emailSettings, ...config.emailSettings } };
};

export const saveConfig = (config: SalonConfig): void => {
  localStorage.setItem(KEYS.CONFIG, JSON.stringify(config));
};

// --- Customer Preferences ---
export const getCustomerPreferences = (): CustomerPreferences => {
  const stored = localStorage.getItem(KEYS.CUSTOMER_PREFS);
  return stored ? JSON.parse(stored) : DEFAULT_CUSTOMER_PREFS;
};

export const saveCustomerPreferences = (prefs: CustomerPreferences): void => {
  localStorage.setItem(KEYS.CUSTOMER_PREFS, JSON.stringify(prefs));
};

// --- Real Gmail API Logic ---
export const sendGmailEmail = async (recipient: string, subject: string, body: string, token: string, sender: string) => {
  // Construct the raw email message following RFC 2822 formatting
  const messageParts = [
    `From: "Lumière Salon" <${sender}>`,
    `To: ${recipient}`,
    `Subject: ${subject}`,
    `Content-Type: text/plain; charset=utf-8`,
    `MIME-Version: 1.0`,
    ``,
    body
  ];
  
  const message = messageParts.join('\n');

  // Browser-compatible Base64URL encoding (Polyfill for Node Buffer)
  // 1. Encode URI component to handle UTF-8
  // 2. btoa to get base64
  // 3. Replace chars for URL safety
  const encodedMessage = btoa(unescape(encodeURIComponent(message)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  try {
    const res = await fetch(
      "https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ raw: encodedMessage })
      }
    );
    
    const result = await res.json();
    
    if (res.ok) {
      console.log('[GMAIL API] Email Sent Successfully', result);
      return { success: true, result };
    } else {
      console.error('[GMAIL API] Error:', result);
      return { success: false, error: result };
    }
  } catch (error) {
    console.error('[GMAIL API] Network Error:', error);
    return { success: false, error };
  }
};

// --- Notifications ---
export const getNotifications = (): Notification[] => {
  const stored = localStorage.getItem(KEYS.NOTIFICATIONS);
  return stored ? JSON.parse(stored) : [];
};

export const createNotification = (data: Omit<Notification, 'id' | 'timestamp' | 'read' | 'deliveryMethod'>): void => {
  const notifications = getNotifications();
  const config = getConfig();
  
  // Use the integrated email as default if not present
  const sender = config.emailSettings.gmailAddress || 'adil.mushtaq67@gmail.com';

  const newNotification: Notification = {
    ...data,
    id: generateId(),
    sender: sender,
    timestamp: new Date().toISOString(),
    read: false,
    deliveryMethod: config.emailSettings.provider
  };
  
  // Add to beginning
  notifications.unshift(newNotification);
  localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  
  const isGmail = config.emailSettings.provider === 'gmail';
  const hasToken = !!config.emailSettings.gmailAccessToken;

  // Clean log output
  console.log(`[NOTIFICATION SYSTEM] Processing via ${isGmail ? 'Gmail' : 'Simulation'}...`);
  console.log(`[HEADER] From: ${sender} | To: ${data.recipient}`);
  
  // Trigger Real API call if configured
  if (isGmail && hasToken) {
    const subject = data.type === 'confirmation' 
      ? `Booking Update - Lumière Salon`
      : data.type === 'availability' 
        ? `Slot Available - Lumière Salon` 
        : `Reminder - Lumière Salon`;
        
    // Execute async send without blocking UI
    sendGmailEmail(data.recipient, subject, data.message, config.emailSettings.gmailAccessToken!, sender)
      .then(res => {
        if (!res.success) {
           console.warn('[GMAIL API] Failed to send email via API. Check console errors.');
        }
      });
  } else if (isGmail && !hasToken) {
    console.warn('[GMAIL API] Skipping real send: Access Token missing in configuration.');
  }
};

export const markNotificationRead = (id: string): void => {
  const notifications = getNotifications();
  const notification = notifications.find(n => n.id === id);
  if (notification) {
    notification.read = true;
    localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }
};

// --- Waitlist ---
export const getWaitlist = (): WaitlistEntry[] => {
  const stored = localStorage.getItem(KEYS.WAITLIST);
  return stored ? JSON.parse(stored) : [];
};

export const addToWaitlist = (entry: Omit<WaitlistEntry, 'id' | 'createdAt'>): void => {
  const list = getWaitlist();
  // Avoid duplicates
  if (list.some(e => e.email === entry.email && e.date === entry.date)) return;

  const newEntry: WaitlistEntry = {
    ...entry,
    id: generateId(),
    createdAt: new Date().toISOString(),
  } as WaitlistEntry;
  list.push(newEntry);
  localStorage.setItem(KEYS.WAITLIST, JSON.stringify(list));
};

const checkWaitlistAndNotify = (date: string) => {
  const list = getWaitlist();
  const interested = list.filter(e => e.date === date);
  
  interested.forEach(entry => {
    createNotification({
      recipient: entry.email,
      type: 'availability',
      message: `Good News! A slot has opened up on ${date}. Visit Lumière Salon to book now.`,
    });
  });
};

// --- Payment ---
export const processPayment = async (amount: number, cardDetails: { number: string }): Promise<{ success: boolean; transactionId?: string }> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Basic validation simulation
  if (amount > 0 && cardDetails.number.length >= 13) {
    return { 
      success: true, 
      transactionId: `txn_${generateId().slice(0, 10)}` 
    };
  }
  return { success: false };
};

// --- Bookings ---
export const getBookings = (): Booking[] => {
  const stored = localStorage.getItem(KEYS.BOOKINGS);
  return stored ? JSON.parse(stored) : [];
};

export const saveBooking = (booking: Booking): void => {
  const bookings = getBookings();
  // Initialize reminder status
  booking.remindersSent = { h24: false, h1: false };
  
  // Find service price for reporting if not present
  if (!booking.price) {
     const services = getServices();
     const service = services.find(s => s.id === booking.serviceId);
     booking.price = service ? service.price : 0;
  }

  bookings.push(booking);
  localStorage.setItem(KEYS.BOOKINGS, JSON.stringify(bookings));
  
  // Check preferences before sending confirmation
  const prefs = getCustomerPreferences();
  if (prefs.receiveConfirmations) {
    // Generate management link (assuming hash router)
    const manageLink = `${window.location.origin}${window.location.pathname}#/my-bookings`;
    
    const paymentInfo = booking.paymentStatus === 'paid' 
      ? `Payment Status: PAID\nTransaction ID: ${booking.transactionId}` 
      : `Payment Status: Pending`;

    createNotification({
      recipient: booking.customerEmail,
      type: 'confirmation',
      message: `CONFIRMED: Appointment #${booking.id.slice(0, 8).toUpperCase()}
      
Service: ${booking.serviceName}
Date: ${booking.date}
Time: ${booking.timeSlot}
Price: $${booking.price}
${paymentInfo}

To manage or cancel this booking, please visit:
${manageLink}

Thank you for choosing Lumière Salon.`
    });
  }
};

export const rescheduleBooking = (id: string, newDate: string, newTime: string): void => {
  const bookings = getBookings();
  const index = bookings.findIndex(b => b.id === id);
  
  if (index !== -1) {
    const oldDate = bookings[index].date;
    const oldTime = bookings[index].timeSlot;
    
    bookings[index].date = newDate;
    bookings[index].timeSlot = newTime;
    bookings[index].status = 'confirmed'; // Reset status if it was cancelled
    bookings[index].remindersSent = { h24: false, h1: false }; // Reset reminders
    
    localStorage.setItem(KEYS.BOOKINGS, JSON.stringify(bookings));
    
    // Notify Customer
    const prefs = getCustomerPreferences();
    if (prefs.receiveConfirmations) {
       createNotification({
        recipient: bookings[index].customerEmail,
        type: 'confirmation',
        message: `RESCHEDULED: Appointment #${id.slice(0, 8).toUpperCase()}
        
Your appointment has been successfully moved.

New Date: ${newDate}
New Time: ${newTime}
Service: ${bookings[index].serviceName}

(Previous: ${oldDate} @ ${oldTime})

Thank you for choosing Lumière Salon.`
      });
    }

    // Check waitlist for the old date that just freed up
    checkWaitlistAndNotify(oldDate);
  }
};

export const saveAllBookings = (bookings: Booking[]): void => {
  localStorage.setItem(KEYS.BOOKINGS, JSON.stringify(bookings));
};

export const updateBookingStatus = (id: string, status: Booking['status']): void => {
  const bookings = getBookings();
  const index = bookings.findIndex(b => b.id === id);
  if (index !== -1) {
    bookings[index].status = status;
    if (status === 'cancelled' && bookings[index].paymentStatus === 'paid') {
      bookings[index].paymentStatus = 'refunded'; // Auto-mark refund if cancelled (simulated)
    }
    localStorage.setItem(KEYS.BOOKINGS, JSON.stringify(bookings));

    if (status === 'cancelled') {
      checkWaitlistAndNotify(bookings[index].date);
    }
  }
};

export const getDashboardStats = () => {
  const bookings = getBookings();
  const confirmed = bookings.filter(b => b.status === 'confirmed');
  const revenue = confirmed.reduce((sum, b) => sum + (b.price || 0), 0);
  
  // Get unique customers
  const customers = new Set(bookings.map(b => b.customerEmail)).size;

  return {
    totalRevenue: revenue,
    activeBookings: confirmed.length,
    totalCustomers: customers
  };
};

// --- Services ---
export const getServices = (): Service[] => {
  const stored = localStorage.getItem(KEYS.SERVICES);
  return stored ? JSON.parse(stored) : DEFAULT_SERVICES;
};

export const saveService = (service: Service): void => {
  const services = getServices();
  const index = services.findIndex(s => s.id === service.id);
  if (index >= 0) {
    services[index] = service;
  } else {
    services.push(service);
  }
  localStorage.setItem(KEYS.SERVICES, JSON.stringify(services));
};

export const deleteService = (id: string): void => {
  const services = getServices();
  const newServices = services.filter(s => s.id !== id);
  localStorage.setItem(KEYS.SERVICES, JSON.stringify(newServices));
};
