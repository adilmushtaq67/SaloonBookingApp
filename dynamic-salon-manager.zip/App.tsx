
import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route, Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { 
  getConfig, getServices, getBookings, saveBooking, 
  saveService, deleteService, saveConfig, 
  getNotifications, createNotification, markNotificationRead,
  updateBookingStatus, addToWaitlist, saveAllBookings, getDashboardStats,
  getCustomerPreferences, saveCustomerPreferences, sendGmailEmail, rescheduleBooking,
  validateAdminCredentials, setAdminSession, checkAdminSession, processPayment
} from './services/storageService';
import { Booking, SalonConfig, Service, TimeSlot, Role, Notification, DEFAULT_CONFIG, CustomerPreferences, DEFAULT_CUSTOMER_PREFS } from './types';
import { CalendarIcon, ClockIcon, UserIcon, CheckIcon, MailIcon, SparklesIcon, LockIcon, TrashIcon, PlusIcon, ChevronLeftIcon, ChevronRightIcon, TrendingUpIcon, DollarIcon, CreditCardIcon } from './components/Icons';
import { Assistant } from './components/Assistant';

// --- Constants ---
const GOOGLE_CLIENT_ID = "594390673477-99u3c3aptbteogartflrgeu075u9ui1f.apps.googleusercontent.com";

// --- Utility Functions ---

const generateTimeSlots = (date: string, config: SalonConfig, bookings: Booking[]): TimeSlot[] => {
  const slots: TimeSlot[] = [];
  const [openHour, openMinute] = config.openTime.split(':').map(Number);
  const [closeHour, closeMinute] = config.closeTime.split(':').map(Number);
  
  const start = new Date(`${date}T${config.openTime}`);
  const end = new Date(`${date}T${config.closeTime}`);
  
  // Create current date object for comparison
  const now = new Date();
  const isToday = now.toISOString().split('T')[0] === date;

  let current = new Date(start);

  while (current < end) {
    const timeString = current.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
    
    // Check bookings
    const booking = bookings.find(b => b.date === date && b.timeSlot === timeString && b.status !== 'cancelled');
    
    // Check if passed
    let status: TimeSlot['status'] = 'available';
    if (booking) {
      status = 'booked';
    } else if (isToday && current < now) {
      status = 'past';
    } else if (config.holidays.includes(date)) {
      status = 'blocked';
    }

    slots.push({
      time: timeString,
      status,
      bookingId: booking?.id
    });

    current.setMinutes(current.getMinutes() + config.slotInterval);
  }

  return slots;
};

// --- Components ---

const Layout = ({ children, role, setRole, notifications, onLogout }: React.PropsWithChildren<{ role: Role, setRole: (r: Role) => void, notifications: Notification[], onLogout: () => void }>) => {
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900 overflow-x-hidden relative">
      {/* Mature Background Elements (Subtle Fog) */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-slate-50">
        <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-white to-transparent opacity-80"></div>
        <div className="absolute top-[-10%] right-[-10%] w-[800px] h-[800px] rounded-full bg-slate-200/40 blur-[120px]"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] rounded-full bg-indigo-50/60 blur-[120px]"></div>
      </div>

      <nav className="fixed top-0 w-full z-40 bg-white/90 backdrop-blur-md border-b border-slate-200 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-slate-900 rounded-lg flex items-center justify-center shadow-md shadow-slate-300">
                  <span className="font-serif text-white font-bold text-xl italic">L</span>
              </div>
              <Link to="/" className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
                Lumière
              </Link>
            </div>
            <div className="flex items-center space-x-8">
              <Link to="/" className="text-sm font-semibold text-slate-600 hover:text-indigo-600 transition-colors tracking-wide">BOOKING</Link>
              <Link to="/my-bookings" className="text-sm font-semibold text-slate-600 hover:text-indigo-600 transition-colors tracking-wide">MY APPOINTMENTS</Link>
              {role === 'admin' && (
                <Link to="/admin" className="text-sm font-semibold text-slate-600 hover:text-indigo-600 transition-colors tracking-wide flex items-center gap-2">
                  DASHBOARD
                  {unreadCount > 0 && <span className="bg-rose-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-sm">{unreadCount}</span>}
                </Link>
              )}
              {role === 'admin' ? (
                <button 
                  onClick={onLogout}
                  className="hidden md:block text-xs font-bold border-2 border-rose-100 text-rose-600 rounded-md px-4 py-2 hover:border-rose-200 hover:bg-rose-50 transition-all uppercase tracking-widest"
                >
                  Logout
                </button>
              ) : (
                <Link 
                  to="/login"
                  className="hidden md:block text-xs font-bold border-2 border-slate-200 rounded-md px-4 py-2 hover:border-slate-900 hover:bg-slate-900 hover:text-white transition-all text-slate-600 uppercase tracking-widest"
                >
                  Admin Login
                </Link>
              )}
            </div>
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mt-20 relative z-10">
        {children}
      </main>
      <footer className="relative z-10 bg-white border-t border-slate-200 py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
            <p className="font-serif text-xl font-bold text-slate-900 mb-2">Lumière Salon</p>
            <p className="text-slate-500 text-sm font-medium tracking-wide uppercase">Precision Styling & Aesthetics</p>
            <div className="mt-8 text-xs text-slate-400">
             &copy; {new Date().getFullYear()} Lumière System. Powered by Gemini AI.
            </div>
        </div>
      </footer>
    </div>
  );
};

// --- Pages ---

const LoginPage = ({ onLogin }: { onLogin: (r: Role) => void }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateAdminCredentials(email, password)) {
      setAdminSession(true);
      onLogin('admin');
      navigate('/admin');
    } else {
      setError('Invalid email or password.');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-12 animate-fade-in">
      <div className="bg-white p-8 rounded-lg shadow-xl border border-slate-200">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-slate-900 rounded-lg flex items-center justify-center mx-auto mb-4 shadow-lg">
             <LockIcon className="w-6 h-6 text-indigo-400" />
          </div>
          <h2 className="font-serif text-2xl font-bold text-slate-900">Admin Portal</h2>
          <p className="text-slate-500 text-sm mt-1">Please authenticate to continue.</p>
        </div>

        {error && (
          <div className="bg-rose-50 border border-rose-200 text-rose-600 px-4 py-3 rounded text-sm mb-6 flex items-center gap-2">
            <span className="font-bold">Error:</span> {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">Email Address</label>
            <input 
              type="email" 
              required
              className="w-full border border-slate-300 rounded px-4 py-3 text-sm focus:border-indigo-500 outline-none bg-slate-50"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="admin@lumiere.com"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">Password</label>
            <input 
              type="password" 
              required
              className="w-full border border-slate-300 rounded px-4 py-3 text-sm focus:border-indigo-500 outline-none bg-slate-50"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>
          <button type="submit" className="w-full bg-slate-900 text-white font-bold py-3 rounded hover:bg-slate-800 transition-colors shadow-lg uppercase tracking-wide text-xs">
            Authenticate
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-400">
            For demo access use:<br/>
            <span className="font-mono text-indigo-600">adil.mushtaq67@gmail.com</span> / <span className="font-mono text-indigo-600">admin123</span>
          </p>
        </div>
      </div>
    </div>
  );
};

const BookingPage = () => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [services, setServices] = useState<Service[]>([]);
  const [config, setConfig] = useState<SalonConfig>(DEFAULT_CONFIG);
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', notes: '' });
  const [paymentForm, setPaymentForm] = useState({ number: '', expiry: '', cvv: '', name: '' });
  const [slots, setSlots] = useState<TimeSlot[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [lastBookingId, setLastBookingId] = useState<string>('');
  
  // Waitlist state
  const [showWaitlistInput, setShowWaitlistInput] = useState(false);
  const [waitlistEmail, setWaitlistEmail] = useState('');

  useEffect(() => {
    setServices(getServices());
    setConfig(getConfig());
    setLoading(false);
  }, []);

  useEffect(() => {
    if (selectedDate && config) {
      const allBookings = getBookings();
      setSlots(generateTimeSlots(selectedDate, config, allBookings));
      setShowWaitlistInput(false);
      setWaitlistEmail('');
    }
  }, [selectedDate, config]);

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(3); // Go to Payment
  };

  const handlePaymentAndBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService || !selectedSlot) return;

    setProcessingPayment(true);

    const result = await processPayment(selectedService.price, { number: paymentForm.number });

    if (result.success) {
      const newBookingId = crypto.randomUUID();
      const newBooking: Booking = {
        id: newBookingId,
        customerId: crypto.randomUUID(),
        customerName: formData.name,
        customerEmail: formData.email,
        customerPhone: formData.phone,
        serviceId: selectedService.id,
        serviceName: selectedService.name,
        price: selectedService.price,
        date: selectedDate,
        timeSlot: selectedSlot,
        status: 'confirmed',
        paymentStatus: 'paid',
        transactionId: result.transactionId,
        notes: formData.notes,
        createdAt: new Date().toISOString()
      };

      saveBooking(newBooking);
      setLastBookingId(newBookingId);
      setStep(4);
    } else {
      alert("Payment failed. Please check your card details.");
    }
    setProcessingPayment(false);
  };

  const handleWaitlist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!waitlistEmail) return;
    addToWaitlist({ email: waitlistEmail, date: selectedDate });
    createNotification({
      recipient: waitlistEmail,
      type: 'availability',
      message: `Waitlist Confirmed: We will notify you if a slot opens on ${selectedDate}.`
    });
    alert("You're on the waitlist. Notification enabled.");
    setShowWaitlistInput(false);
    setWaitlistEmail('');
  };

  if (loading) return <div className="p-12 text-center text-slate-400 font-serif animate-pulse">Initializing System...</div>;

  return (
    <div>
       {step === 1 && (
         <div className="animate-fade-in">
           {/* Hero Section - Mature Dark Card */}
           <div className="relative bg-slate-900 rounded-2xl overflow-hidden mb-12 shadow-2xl shadow-slate-300 min-h-[300px] flex items-center justify-center border border-slate-800">
              {/* Subtle Grid Pattern */}
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
              <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 opacity-95"></div>
              
              <div className="relative z-10 text-center px-6 max-w-2xl mx-auto">
                <span className="inline-block py-1 px-3 rounded border border-slate-700 text-slate-300 text-[10px] font-bold tracking-[0.2em] mb-6 uppercase bg-slate-800/50 backdrop-blur-sm">
                  Professional Booking Portal
                </span>
                <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl mb-4 font-medium leading-tight text-white tracking-tight">
                  Refined. <span className="text-indigo-400 italic">Intelligent.</span>
                </h1>
                <p className="text-slate-400 text-sm md:text-base font-light leading-relaxed max-w-lg mx-auto">
                  Select your service to begin the reservation process.
                </p>
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
             {/* Left Col: Service & Date */}
             <div className="lg:col-span-4 space-y-6">
               
               <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
                 <h2 className="text-lg font-bold mb-6 flex items-center gap-2 text-slate-900 uppercase tracking-wide text-xs">
                    1. Select Service
                 </h2>
                 <div className="space-y-3">
                   {services.map(s => (
                     <div 
                      key={s.id}
                      onClick={() => setSelectedService(s)}
                      className={`group p-4 rounded-md border cursor-pointer transition-all duration-200 ${
                        selectedService?.id === s.id 
                          ? 'border-indigo-600 bg-slate-900 text-white shadow-lg shadow-indigo-500/20' 
                          : 'border-slate-200 bg-white hover:border-slate-400 hover:bg-slate-50'
                      }`}
                     >
                       <div className="flex justify-between items-center mb-1">
                          <span className={`font-semibold text-sm ${selectedService?.id === s.id ? 'text-white' : 'text-slate-900'}`}>{s.name}</span>
                          <span className={`font-serif ${selectedService?.id === s.id ? 'text-indigo-300' : 'text-slate-600'}`}>${s.price}</span>
                       </div>
                       <div className="flex justify-between items-center">
                         <p className={`text-xs truncate max-w-[70%] ${selectedService?.id === s.id ? 'text-slate-400' : 'text-slate-500'}`}>{s.description}</p>
                         <span className={`text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded ${selectedService?.id === s.id ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'}`}>{s.duration} min</span>
                       </div>
                     </div>
                   ))}
                 </div>
               </div>

               <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
                  <h2 className="text-lg font-bold mb-6 flex items-center gap-2 text-slate-900 uppercase tracking-wide text-xs">
                     2. Select Date
                  </h2>
                  <input 
                    type="date" 
                    value={selectedDate}
                    min={new Date().toISOString().split('T')[0]}
                    onChange={(e) => {
                      setSelectedDate(e.target.value);
                      setSelectedSlot(null);
                    }}
                    className="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-medium text-slate-700 bg-slate-50 hover:bg-white transition-all cursor-pointer text-sm"
                  />
               </div>
             </div>

             {/* Right Col: Slots & Form */}
             <div className="lg:col-span-8">
                <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-200 min-h-[600px] h-full flex flex-col">
                  <div className="flex items-baseline justify-between mb-8 border-b border-slate-100 pb-4">
                    <div>
                      <h2 className="text-2xl font-serif font-bold text-slate-900 mb-1">Availability</h2>
                      <p className="text-indigo-600 font-semibold tracking-wide text-xs uppercase">{new Date(selectedDate).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</p>
                    </div>
                    {selectedService && (
                      <span className="text-slate-500 text-sm font-medium">Step 3: Choose Time</span>
                    )}
                  </div>

                  {!selectedService ? (
                    <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                      <ClockIcon className="w-12 h-12 mb-3 opacity-20" />
                      <p className="font-serif italic">Please select a service first.</p>
                    </div>
                  ) : (
                    <div className="flex-1">
                      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3 mb-8">
                        {slots.map((slot, idx) => (
                          <button
                            key={idx}
                            disabled={slot.status !== 'available'}
                            onClick={() => setSelectedSlot(slot.time)}
                            className={`
                              relative p-3 rounded-md text-sm font-medium transition-all duration-200 flex flex-col items-center justify-center border shadow-sm
                              ${slot.status === 'available' && selectedSlot === slot.time 
                                ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-200 scale-105 z-10' 
                                : ''}
                              ${slot.status === 'available' && selectedSlot !== slot.time 
                                ? 'bg-white border-slate-200 text-emerald-600 hover:border-emerald-500 hover:text-emerald-700 hover:shadow-md' 
                                : ''}
                              ${slot.status === 'booked' 
                                ? 'bg-rose-50 border-rose-100 text-rose-400 cursor-not-allowed opacity-80' 
                                : ''}
                              ${slot.status === 'blocked' || slot.status === 'past' 
                                ? 'bg-slate-50 border-slate-100 text-slate-300 cursor-not-allowed' 
                                : ''}
                            `}
                          >
                            <span>{slot.time}</span>
                            {slot.status === 'booked' && <span className="text-[9px] uppercase tracking-tighter mt-1 font-bold text-rose-500">Booked</span>}
                            {slot.status === 'available' && selectedSlot === slot.time && (
                              <div className="absolute -top-1 -right-1 w-2 h-2 bg-white rounded-full animate-ping"></div>
                            )}
                          </button>
                        ))}
                      </div>

                      {slots.every(s => s.status !== 'available') && (
                        <div className="bg-slate-50 border border-slate-200 rounded-lg p-6 text-center">
                          <p className="text-slate-600 mb-4 font-medium">Fully booked for this date.</p>
                          {!showWaitlistInput ? (
                            <button 
                              onClick={() => setShowWaitlistInput(true)}
                              className="text-indigo-600 hover:text-indigo-800 text-sm font-semibold flex items-center justify-center gap-2 mx-auto"
                            >
                              <MailIcon className="w-4 h-4" /> Notify me if a slot opens
                            </button>
                          ) : (
                            <form onSubmit={handleWaitlist} className="flex gap-2 max-w-sm mx-auto">
                              <input 
                                type="email" 
                                required
                                placeholder="Enter email address"
                                value={waitlistEmail}
                                onChange={e => setWaitlistEmail(e.target.value)}
                                className="flex-1 text-sm border border-slate-300 rounded-md px-3 py-2 outline-none focus:border-indigo-500"
                              />
                              <button type="submit" className="bg-indigo-600 text-white text-xs px-4 py-2 rounded-md hover:bg-indigo-700 font-bold uppercase tracking-wide">
                                Join Waitlist
                              </button>
                            </form>
                          )}
                        </div>
                      )}

                      {/* Summary & Continue */}
                      <div className={`mt-8 border-t border-slate-100 pt-6 transition-all duration-500 ${selectedSlot ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Selected</p>
                            <p className="text-lg font-serif font-bold text-slate-900">
                              {selectedService.name} <span className="text-indigo-400 mx-2">•</span> {selectedSlot}
                            </p>
                          </div>
                          <button 
                            onClick={() => setStep(2)}
                            className="bg-indigo-600 text-white px-8 py-3 rounded-md font-bold text-sm hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100 tracking-wide uppercase"
                          >
                            Proceed to Details &rarr;
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
             </div>
           </div>
         </div>
       )}

       {step === 2 && (
         <div className="max-w-2xl mx-auto animate-slide-up">
           <button onClick={() => setStep(1)} className="mb-6 text-slate-500 hover:text-slate-900 flex items-center gap-2 text-sm font-medium transition-colors">
             <ChevronLeftIcon className="w-4 h-4" /> Back to Calendar
           </button>
           
           <div className="bg-white rounded-lg shadow-xl shadow-slate-200 border border-slate-200 overflow-hidden">
             <div className="bg-slate-900 p-8 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 p-12 opacity-10">
                   <UserIcon className="w-64 h-64" />
                </div>
                <h2 className="text-2xl font-serif font-bold relative z-10">Your Details</h2>
                <p className="text-slate-400 relative z-10 mt-2 text-sm">Please provide your contact details securely.</p>
             </div>
             
             <div className="p-8">
               <div className="flex gap-4 mb-8 bg-slate-50 p-4 rounded-md border border-slate-200">
                 <div className="flex-1">
                   <p className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-1">Service</p>
                   <p className="font-semibold text-slate-800">{selectedService?.name}</p>
                 </div>
                 <div className="flex-1 border-l border-slate-200 pl-4">
                   <p className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-1">Time</p>
                   <p className="font-semibold text-slate-800">{selectedDate} @ {selectedSlot}</p>
                 </div>
                 <div className="flex-1 border-l border-slate-200 pl-4">
                   <p className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-1">Total</p>
                   <p className="font-serif font-bold text-indigo-600 text-lg">${selectedService?.price}</p>
                 </div>
               </div>

               <form onSubmit={handleDetailsSubmit} className="space-y-6">
                 <div className="grid grid-cols-2 gap-6">
                   <div>
                     <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">Full Name</label>
                     <input 
                       required 
                       className="w-full bg-slate-50 border border-slate-300 rounded-md px-4 py-3 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
                       value={formData.name}
                       onChange={e => setFormData({...formData, name: e.target.value})}
                   />
                   </div>
                   <div>
                     <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">Phone</label>
                     <input 
                       required 
                       type="tel"
                       className="w-full bg-slate-50 border border-slate-300 rounded-md px-4 py-3 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
                       value={formData.phone}
                       onChange={e => setFormData({...formData, phone: e.target.value})}
                     />
                   </div>
                 </div>
                 
                 <div>
                   <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">Email Address</label>
                   <input 
                     required 
                     type="email"
                     className="w-full bg-slate-50 border border-slate-300 rounded-md px-4 py-3 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
                     value={formData.email}
                     onChange={e => setFormData({...formData, email: e.target.value})}
                   />
                 </div>

                 <div>
                   <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">Special Requests (Optional)</label>
                   <textarea 
                     className="w-full bg-slate-50 border border-slate-300 rounded-md px-4 py-3 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all h-24 resize-none"
                     value={formData.notes}
                     onChange={e => setFormData({...formData, notes: e.target.value})}
                   />
                 </div>

                 <button type="submit" className="w-full bg-slate-900 text-white font-bold py-4 rounded-md hover:bg-slate-800 transition-all shadow-lg text-sm tracking-widest uppercase flex justify-between px-6 items-center">
                   <span>Continue to Payment</span>
                   <span>&rarr;</span>
                 </button>
               </form>
             </div>
           </div>
         </div>
       )}

      {step === 3 && (
         <div className="max-w-2xl mx-auto animate-slide-up">
            <button onClick={() => setStep(2)} className="mb-6 text-slate-500 hover:text-slate-900 flex items-center gap-2 text-sm font-medium transition-colors">
              <ChevronLeftIcon className="w-4 h-4" /> Back to Details
            </button>

            <div className="bg-white rounded-lg shadow-xl shadow-slate-200 border border-slate-200 overflow-hidden">
                <div className="bg-indigo-900 p-8 text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-8 opacity-10">
                       <CreditCardIcon className="w-64 h-64" />
                    </div>
                    <h2 className="text-2xl font-serif font-bold relative z-10 flex items-center gap-3">
                       <LockIcon className="w-6 h-6 text-indigo-300"/> Secure Payment
                    </h2>
                    <p className="text-indigo-200 relative z-10 mt-2 text-sm">Complete your reservation.</p>
                </div>

                <div className="p-8 grid md:grid-cols-2 gap-8">
                   {/* Order Summary */}
                   <div className="bg-slate-50 p-6 rounded-lg border border-slate-200 h-fit">
                      <h3 className="font-bold text-slate-900 uppercase text-xs tracking-wider mb-4 border-b border-slate-200 pb-2">Order Summary</h3>
                      <div className="space-y-4">
                         <div className="flex justify-between">
                            <span className="text-slate-600 text-sm">Service</span>
                            <span className="font-medium text-slate-900 text-sm">{selectedService?.name}</span>
                         </div>
                         <div className="flex justify-between">
                            <span className="text-slate-600 text-sm">Date</span>
                            <span className="font-medium text-slate-900 text-sm">{selectedDate}</span>
                         </div>
                         <div className="flex justify-between">
                            <span className="text-slate-600 text-sm">Time</span>
                            <span className="font-medium text-slate-900 text-sm">{selectedSlot}</span>
                         </div>
                         <div className="border-t border-slate-200 pt-3 flex justify-between items-center mt-2">
                            <span className="font-bold text-slate-900">Total Due</span>
                            <span className="font-serif font-bold text-2xl text-indigo-600">${selectedService?.price}</span>
                         </div>
                      </div>
                   </div>

                   {/* Payment Form */}
                   <form onSubmit={handlePaymentAndBook} className="space-y-4">
                      <div>
                         <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Card Number</label>
                         <div className="relative">
                            <input 
                              required
                              type="text"
                              maxLength={19}
                              placeholder="0000 0000 0000 0000"
                              className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none pl-10"
                              value={paymentForm.number}
                              onChange={e => setPaymentForm({...paymentForm, number: e.target.value})}
                            />
                            <CreditCardIcon className="w-4 h-4 text-slate-400 absolute left-3 top-2.5"/>
                         </div>
                      </div>
                      
                      <div>
                         <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Cardholder Name</label>
                         <input 
                            required
                            type="text"
                            placeholder="JOHN DOE"
                            className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none"
                            value={paymentForm.name}
                            onChange={e => setPaymentForm({...paymentForm, name: e.target.value})}
                         />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Expiry</label>
                            <input 
                              required
                              type="text"
                              placeholder="MM/YY"
                              maxLength={5}
                              className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none"
                              value={paymentForm.expiry}
                              onChange={e => setPaymentForm({...paymentForm, expiry: e.target.value})}
                            />
                         </div>
                         <div>
                            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">CVV</label>
                            <input 
                              required
                              type="text"
                              maxLength={3}
                              placeholder="123"
                              className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none"
                              value={paymentForm.cvv}
                              onChange={e => setPaymentForm({...paymentForm, cvv: e.target.value})}
                            />
                         </div>
                      </div>

                      <button 
                        type="submit" 
                        disabled={processingPayment}
                        className="w-full bg-emerald-600 text-white font-bold py-3 rounded-md hover:bg-emerald-700 transition-all shadow-lg text-sm tracking-widest uppercase mt-4 disabled:opacity-70 disabled:cursor-wait"
                      >
                        {processingPayment ? 'Processing...' : `Pay $${selectedService?.price} & Book`}
                      </button>
                      <p className="text-[10px] text-center text-slate-400 mt-2 flex items-center justify-center gap-1">
                        <LockIcon className="w-3 h-3"/> Payments are secure and encrypted.
                      </p>
                   </form>
                </div>
            </div>
         </div>
      )}

       {step === 4 && (
         <div className="max-w-md mx-auto text-center animate-fade-in pt-12">
           <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-emerald-50">
             <CheckIcon className="w-10 h-10 text-emerald-600" />
           </div>
           <h2 className="text-3xl font-serif font-bold text-slate-900 mb-2">Booking Confirmed</h2>
           <p className="text-slate-500 mb-8">Your appointment has been successfully scheduled and paid.</p>
           
           <div className="bg-white p-6 rounded-lg shadow-lg border border-slate-200 mb-8 text-left relative overflow-hidden">
             <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500"></div>
             <div className="flex justify-between items-center mb-4">
                <p className="text-sm text-slate-600">Confirmation sent to:</p>
                <span className="bg-indigo-50 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded border border-indigo-100">From: adil.mushtaq67@gmail.com</span>
             </div>
             <p className="font-semibold text-slate-900 mb-1">{formData.email}</p>
             <p className="text-xs text-slate-400 font-mono mb-4">ID: {lastBookingId}</p>

             <div className="border-t border-slate-100 pt-4 mt-4 grid grid-cols-2 gap-4">
               <div>
                  <p className="text-xs text-slate-400 uppercase">Date</p>
                  <p className="font-medium text-slate-800">{selectedDate}</p>
               </div>
               <div>
                  <p className="text-xs text-slate-400 uppercase">Time</p>
                  <p className="font-medium text-slate-800">{selectedSlot}</p>
               </div>
               <div className="col-span-2">
                  <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-1 rounded-full border border-emerald-200">
                    PAID ${selectedService?.price}
                  </span>
               </div>
             </div>
           </div>

           <Link to="/my-bookings" onClick={() => {}} className="text-indigo-600 font-semibold hover:text-indigo-800 text-sm tracking-wide uppercase">
             Manage My Booking
           </Link>
         </div>
       )}

       {/* Floating AI Assistant */}
       <Assistant services={services} todaySlots={slots} />
    </div>
  );
};

const CustomerDashboard = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [prefs, setPrefs] = useState<CustomerPreferences>(DEFAULT_CUSTOMER_PREFS);

  // Reschedule State
  const [reschedulingId, setReschedulingId] = useState<string | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState<string>('');
  const [rescheduleSlots, setRescheduleSlots] = useState<TimeSlot[]>([]);
  const [selectedRescheduleSlot, setSelectedRescheduleSlot] = useState<string | null>(null);

  useEffect(() => {
    refreshBookings();
    setPrefs(getCustomerPreferences());
  }, []);

  const refreshBookings = () => {
    setBookings(getBookings().sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  };

  const handleCancel = (id: string) => {
    if (confirm('Are you sure you want to cancel this appointment?')) {
      updateBookingStatus(id, 'cancelled');
      refreshBookings();
    }
  };

  const togglePref = (key: keyof CustomerPreferences) => {
    const newPrefs = { ...prefs, [key]: !prefs[key] };
    setPrefs(newPrefs);
    saveCustomerPreferences(newPrefs);
  };

  // Reschedule Handlers
  const openRescheduleModal = (booking: Booking) => {
      setReschedulingId(booking.id);
      setRescheduleDate(new Date().toISOString().split('T')[0]); // Default to today
      setSelectedRescheduleSlot(null);
  };

  useEffect(() => {
      if (reschedulingId && rescheduleDate) {
          const config = getConfig();
          const allBookings = getBookings();
          setRescheduleSlots(generateTimeSlots(rescheduleDate, config, allBookings));
      }
  }, [reschedulingId, rescheduleDate]);

  const confirmReschedule = () => {
      if (!reschedulingId || !rescheduleDate || !selectedRescheduleSlot) return;
      rescheduleBooking(reschedulingId, rescheduleDate, selectedRescheduleSlot);
      refreshBookings();
      setReschedulingId(null);
      alert('Appointment rescheduled successfully!');
  };

  return (
    <div className="max-w-3xl mx-auto animate-fade-in space-y-8 relative">
      
      {/* Preferences Section */}
      <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
        <h3 className="text-lg font-serif font-bold text-slate-900 mb-4 flex items-center gap-2">
          <MailIcon className="w-5 h-5 text-indigo-600" /> Notification Preferences
        </h3>
        <div className="space-y-4">
          <label className="flex items-center justify-between p-3 rounded-md border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors cursor-pointer">
            <div>
              <p className="text-sm font-bold text-slate-800">Booking Confirmations</p>
              <p className="text-xs text-slate-500">Receive emails when appointments are booked or cancelled.</p>
            </div>
            <div className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                checked={prefs.receiveConfirmations} 
                onChange={() => togglePref('receiveConfirmations')}
                className="sr-only peer" 
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
            </div>
          </label>

          <label className="flex items-center justify-between p-3 rounded-md border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors cursor-pointer">
            <div>
              <p className="text-sm font-bold text-slate-800">Appointment Reminders</p>
              <p className="text-xs text-slate-500">Receive reminders 24h and 1h before your slot.</p>
            </div>
            <div className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                checked={prefs.receiveReminders} 
                onChange={() => togglePref('receiveReminders')}
                className="sr-only peer" 
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
            </div>
          </label>
        </div>
      </div>

      <div>
        <h2 className="text-3xl font-serif font-bold text-slate-900 mb-6 border-b border-slate-200 pb-4">My Appointments</h2>
        
        {bookings.length === 0 ? (
          <div className="bg-white p-12 rounded-lg border border-slate-200 text-center shadow-sm">
            <p className="text-slate-500 font-serif text-lg">No history found.</p>
            <Link to="/" className="mt-4 inline-block text-indigo-600 font-semibold hover:underline text-sm">Book your first appointment</Link>
          </div>
        ) : (
          <div className="space-y-4">
            {bookings.map(booking => (
              <div key={booking.id} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 flex flex-col sm:flex-row justify-between items-center group hover:border-slate-300 transition-all">
                <div className="mb-4 sm:mb-0 w-full sm:w-auto">
                  <div className="flex items-center gap-3 mb-1">
                    <span className={`w-2.5 h-2.5 rounded-full ${
                      booking.status === 'confirmed' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 
                      booking.status === 'completed' ? 'bg-slate-400' : 'bg-rose-500'
                    }`}></span>
                    <h3 className="font-serif font-bold text-lg text-slate-900">{booking.serviceName}</h3>
                  </div>
                  <p className="text-slate-500 text-sm flex gap-3 mb-2">
                    <span className="flex items-center gap-1"><CalendarIcon className="w-3 h-3" /> {booking.date}</span>
                    <span className="flex items-center gap-1"><ClockIcon className="w-3 h-3" /> {booking.timeSlot}</span>
                  </p>
                  
                  {/* Booking ID & Copy */}
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex items-center gap-2 bg-slate-50 p-1.5 rounded border border-slate-100 w-fit">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">ID:</span>
                      <span className="text-xs font-mono text-slate-600 select-all">{booking.id.slice(0, 8).toUpperCase()}...</span>
                      <button 
                        onClick={() => navigator.clipboard.writeText(booking.id)}
                        className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold ml-1 uppercase"
                      >
                        Copy
                      </button>
                    </div>
                    {booking.paymentStatus === 'paid' && (
                       <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-1 rounded uppercase border border-emerald-100">Paid</span>
                    )}
                  </div>

                  {booking.status === 'cancelled' && <span className="text-xs text-rose-500 font-bold uppercase tracking-wider mt-2 inline-block">Cancelled</span>}
                </div>
                
                {booking.status === 'confirmed' && (
                   <div className="flex gap-2 mt-4 sm:mt-0">
                       <button 
                        onClick={() => openRescheduleModal(booking)}
                        className="px-4 py-2 border border-amber-200 text-amber-600 text-xs font-bold rounded hover:bg-amber-50 hover:border-amber-300 transition-colors uppercase tracking-wider whitespace-nowrap"
                       >
                         Reschedule
                       </button>
                       <button 
                        onClick={() => handleCancel(booking.id)}
                        className="px-4 py-2 border border-slate-200 text-slate-500 text-xs font-bold rounded hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 transition-colors uppercase tracking-wider whitespace-nowrap"
                       >
                         Cancel
                       </button>
                   </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Reschedule Modal */}
      {reschedulingId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
              <div className="bg-white rounded-lg shadow-2xl w-full max-w-lg overflow-hidden animate-slide-up">
                  <div className="bg-slate-50 border-b border-slate-200 p-4 flex justify-between items-center">
                      <h4 className="font-bold text-slate-800 flex items-center gap-2"><ClockIcon className="w-4 h-4 text-amber-600"/> Reschedule Appointment</h4>
                      <button onClick={() => setReschedulingId(null)} className="text-slate-400 hover:text-slate-600 text-lg">&times;</button>
                  </div>
                  <div className="p-6">
                      <p className="text-sm text-slate-500 mb-4">Select a new date and time for your appointment.</p>
                      
                      <div className="mb-4">
                          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">New Date</label>
                          <input 
                              type="date" 
                              min={new Date().toISOString().split('T')[0]}
                              value={rescheduleDate}
                              onChange={(e) => {
                                  setRescheduleDate(e.target.value);
                                  setSelectedRescheduleSlot(null);
                              }}
                              className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none"
                          />
                      </div>

                      <div className="mb-6">
                          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Available Slots</label>
                          <div className="grid grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1">
                              {rescheduleSlots.map((slot, idx) => (
                                  <button
                                      key={idx}
                                      disabled={slot.status !== 'available'}
                                      onClick={() => setSelectedRescheduleSlot(slot.time)}
                                      className={`
                                          py-2 px-1 text-xs rounded border transition-colors
                                          ${selectedRescheduleSlot === slot.time 
                                              ? 'bg-amber-500 border-amber-600 text-white font-bold shadow-md' 
                                              : slot.status === 'available'
                                                  ? 'bg-white border-slate-200 text-slate-600 hover:border-amber-400 hover:text-amber-600'
                                                  : 'bg-slate-50 border-slate-100 text-slate-300 cursor-not-allowed'
                                          }
                                      `}
                                  >
                                      {slot.time}
                                  </button>
                              ))}
                          </div>
                          {rescheduleSlots.every(s => s.status !== 'available') && (
                              <p className="text-xs text-rose-500 mt-2 font-medium">No slots available on this date.</p>
                          )}
                      </div>

                      <div className="flex gap-3">
                          <button onClick={() => setReschedulingId(null)} className="flex-1 bg-white border border-slate-300 text-slate-700 font-bold py-3 rounded hover:bg-slate-50 transition-colors text-xs uppercase tracking-wide">Cancel</button>
                          <button 
                              onClick={confirmReschedule}
                              disabled={!selectedRescheduleSlot}
                              className="flex-1 bg-slate-900 text-white font-bold py-3 rounded hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-xs uppercase tracking-wide shadow-lg"
                          >
                              Confirm Change
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState<'bookings' | 'calendar' | 'services' | 'settings' | 'inbox'>('bookings');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [config, setConfig] = useState<SalonConfig>(DEFAULT_CONFIG);
  const [stats, setStats] = useState({ totalRevenue: 0, activeBookings: 0, totalCustomers: 0 });
  
  // Sorting for services
  const [serviceSort, setServiceSort] = useState<{ key: 'name' | 'price' | 'duration', direction: 'asc' | 'desc' }>({ key: 'name', direction: 'asc' });

  // Inbox Filters
  const [notificationFilter, setNotificationFilter] = useState<'all' | 'confirmation' | 'reminder' | 'availability'>('all');

  // Calendar View State
  const [viewDate, setViewDate] = useState(new Date());
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string | null>(null);

  // Email Config Form
  const [emailForm, setEmailForm] = useState({ gmailAddress: '', gmailAppPassword: '', gmailAccessToken: '' });
  // Add Redirect URI state to allow user editing
  const [redirectUri, setRedirectUri] = useState('');

  // Add Service State
  const [isAddingService, setIsAddingService] = useState(false);
  const [newServiceForm, setNewServiceForm] = useState({ name: '', price: 0, duration: 60, description: '' });

  // Email Compose State
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [composeForm, setComposeForm] = useState({ to: '', subject: '', body: '' });

  useEffect(() => {
    refreshData();
  }, [activeTab]); // Trigger refresh when tab changes

  // Initialize Redirect URI on mount
  useEffect(() => {
      setRedirectUri(window.location.origin + window.location.pathname);
  }, []);

  // Auto-detect OAuth token from URL fragment
  useEffect(() => {
    const hash = window.location.hash;
    // Check if the hash contains access_token key (standard implicit flow response)
    if (hash.includes('access_token')) {
      const params = new URLSearchParams(hash.substring(hash.indexOf('#') + 1));
      const token = params.get('access_token');
      if (token) {
        const currentConfig = getConfig();
        const newConfig = { 
          ...currentConfig, 
          emailSettings: { 
            ...currentConfig.emailSettings, 
            gmailAccessToken: token 
          } 
        };
        saveConfig(newConfig);
        setConfig(newConfig);
        setEmailForm(prev => ({ ...prev, gmailAccessToken: token }));
        alert("OAuth Token detected and saved successfully!");
        
        // Clean the URL to avoid re-parsing
        window.history.pushState("", document.title, window.location.pathname + window.location.search);
      }
    }
  }, []);

  const refreshData = () => {
    setBookings(getBookings());
    setServices(getServices());
    setNotifications(getNotifications());
    setConfig(getConfig());
    setStats(getDashboardStats());
    const cfg = getConfig();
    setEmailForm({ 
        gmailAddress: cfg.emailSettings.gmailAddress, 
        gmailAppPassword: cfg.emailSettings.gmailAppPassword || '',
        gmailAccessToken: cfg.emailSettings.gmailAccessToken || ''
    });
  };

  const sortedServices = useMemo(() => {
    return [...services].sort((a, b) => {
      const aValue = a[serviceSort.key];
      const bValue = b[serviceSort.key];
      if (aValue < bValue) return serviceSort.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return serviceSort.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [services, serviceSort]);

  const handleSort = (key: 'name' | 'price' | 'duration') => {
    setServiceSort(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleAddService = (e: React.FormEvent) => {
    e.preventDefault();
    const newService: Service = {
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
      name: newServiceForm.name,
      price: Number(newServiceForm.price),
      duration: Number(newServiceForm.duration),
      description: newServiceForm.description
    };
    saveService(newService);
    refreshData();
    setIsAddingService(false);
    setNewServiceForm({ name: '', price: 0, duration: 60, description: '' });
  };

  const handleSendEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = config.emailSettings.gmailAccessToken;
    const sender = config.emailSettings.gmailAddress || 'adil.mushtaq67@gmail.com';

    if (!token) {
        // Fallback: Ask user if they want to simulate sending
        if (confirm("OAuth Access Token is missing. Do you want to send a SIMULATED email instead?\n\n(No real email will be sent, but it will be logged in the system.)")) {
             createNotification({
                recipient: composeForm.to,
                type: 'reminder',
                message: `[SIMULATED EMAIL] ${composeForm.subject}\n\n${composeForm.body}`
            });
            setShowEmailModal(false);
            setComposeForm({ to: '', subject: '', body: '' });
            refreshData();
            alert('Simulated Email Logged!');
        }
        return;
    }
    
    // Attempt Real Send
    try {
        const res = await sendGmailEmail(composeForm.to, composeForm.subject, composeForm.body, token, sender);
        
        if (res.success) {
             createNotification({
                recipient: composeForm.to,
                type: 'reminder',
                message: `[GMAIL API] ${composeForm.subject}\n\n${composeForm.body}`
            });
            alert('Email Sent Successfully via Gmail API!');
            setShowEmailModal(false);
            setComposeForm({ to: '', subject: '', body: '' });
            refreshData();
        } else {
             alert(`Failed to send email. Error: ${JSON.stringify(res.error)}`);
        }
    } catch (err) {
        alert('An unexpected error occurred while sending email.');
        console.error(err);
    }
  };

  const handleGoogleAuth = () => {
    // UPDATED: Use the user-editable redirect URI state
    let finalRedirectUri = redirectUri;
    
    // Basic sanitization: sometimes trailing slash causes issues if config is exact
    // but we trust the user input primarily now.
    
    const scope = "https://www.googleapis.com/auth/gmail.send";
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${GOOGLE_CLIENT_ID}&redirect_uri=${encodeURIComponent(finalRedirectUri)}&response_type=token&scope=${encodeURIComponent(scope)}&prompt=consent`;
    
    // Log for debug
    console.log('[OAuth] Using Redirect URI:', finalRedirectUri);

    window.open(authUrl, "_blank", "width=500,height=600");
  };

  const saveEmailSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const newConfig: SalonConfig = {
      ...config,
      emailSettings: {
        provider: 'gmail',
        gmailAddress: emailForm.gmailAddress || 'adil.mushtaq67@gmail.com',
        gmailAppPassword: emailForm.gmailAppPassword,
        gmailAccessToken: emailForm.gmailAccessToken
      }
    };
    saveConfig(newConfig);
    setConfig(newConfig);
    
    // Trigger a Test Notification
    createNotification({
        recipient: emailForm.gmailAddress || 'adil.mushtaq67@gmail.com',
        type: 'availability',
        message: 'SMTP Test: Configuration saved and connection simulated successfully.'
    });
    
    refreshData(); // Immediate refresh to show the new notification
    alert('Settings Saved! A test notification has been sent to the Inbox to verify the connection.');
  };

  // --- Calendar View Logic ---
  const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const renderCalendar = () => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    const days = [];

    // Empty slots for start
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-28 bg-slate-50 border border-slate-100/50"></div>);
    }

    // Days
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const dayBookings = bookings.filter(b => b.date === dateStr && b.status !== 'cancelled');
      const isSelected = selectedCalendarDate === dateStr;
      
      // Determine day density color
      const density = dayBookings.length;
      let densityColor = 'bg-slate-100';
      if (density > 0) densityColor = 'bg-emerald-200';
      if (density > 3) densityColor = 'bg-emerald-400';
      if (density > 6) densityColor = 'bg-emerald-600';

      days.push(
        <div 
          key={d} 
          onClick={() => setSelectedCalendarDate(dateStr)}
          className={`h-28 border p-2 cursor-pointer transition-all relative group flex flex-col ${
            isSelected 
              ? 'border-indigo-600 bg-white ring-2 ring-indigo-100 z-10 shadow-lg' 
              : 'border-slate-200 bg-white hover:border-indigo-300 hover:shadow-md'
          }`}
        >
          <div className="flex justify-between items-start mb-2">
            <span className={`text-sm font-bold ${isSelected ? 'text-indigo-700' : 'text-slate-700'}`}>{d}</span>
            {dayBookings.length > 0 && (
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full text-white ${density > 5 ? 'bg-indigo-600' : 'bg-slate-400'}`}>
                {dayBookings.length}
              </span>
            )}
          </div>
          
          <div className="flex-1 space-y-1 overflow-hidden">
             {dayBookings.slice(0, 3).map((b, i) => (
               <div key={i} className="flex items-center gap-1">
                 <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                 <div className="text-[9px] truncate text-slate-500 font-medium">
                   {b.timeSlot}
                 </div>
               </div>
             ))}
             {dayBookings.length > 3 && (
               <div className="text-[9px] text-slate-400 font-medium pl-2.5">+{dayBookings.length - 3} more</div>
             )}
          </div>
          
          {/* Visual Load Bar */}
          {dayBookings.length > 0 && (
             <div className="absolute bottom-0 left-0 w-full h-1 bg-slate-100">
                <div className={`h-full ${density > 5 ? 'bg-rose-500' : 'bg-emerald-500'}`} style={{ width: `${Math.min(density * 15, 100)}%` }}></div>
             </div>
          )}
        </div>
      );
    }
    return days;
  };

  const filteredNotifications = notificationFilter === 'all' 
    ? notifications 
    : notifications.filter(n => n.type === notificationFilter);

  return (
    <div className="animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 border-b border-slate-200 pb-6">
        <div>
          <h1 className="text-3xl font-serif font-bold text-slate-900">Admin Control Center</h1>
          <p className="text-slate-500 text-sm mt-1">Manage operations, configurations, and insights.</p>
        </div>
        <div className="flex space-x-1 bg-white p-1 rounded-lg border border-slate-200 shadow-sm mt-4 md:mt-0">
          {['bookings', 'calendar', 'services', 'inbox', 'settings'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wide transition-all ${
                activeTab === tab ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Row - Professional Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm flex items-center justify-between group hover:border-indigo-200 transition-colors">
           <div>
             <p className="text-xs text-slate-400 font-bold uppercase tracking-wider mb-1">Total Revenue</p>
             <p className="text-2xl font-serif font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">${stats.totalRevenue.toLocaleString()}</p>
           </div>
           <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center border border-emerald-100 group-hover:bg-emerald-100 transition-colors">
             <DollarIcon className="w-6 h-6 text-emerald-600" />
           </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm flex items-center justify-between group hover:border-indigo-200 transition-colors">
           <div>
             <p className="text-xs text-slate-400 font-bold uppercase tracking-wider mb-1">Active Bookings</p>
             <p className="text-2xl font-serif font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{stats.activeBookings}</p>
           </div>
           <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center border border-indigo-100 group-hover:bg-indigo-100 transition-colors">
             <CalendarIcon className="w-6 h-6 text-indigo-600" />
           </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm flex items-center justify-between group hover:border-indigo-200 transition-colors">
           <div>
             <p className="text-xs text-slate-400 font-bold uppercase tracking-wider mb-1">Unique Clients</p>
             <p className="text-2xl font-serif font-bold text-slate-900 group-hover:text-sky-600 transition-colors">{stats.totalCustomers}</p>
           </div>
           <div className="w-12 h-12 rounded-full bg-sky-50 flex items-center justify-center border border-sky-100 group-hover:bg-sky-100 transition-colors">
             <TrendingUpIcon className="w-6 h-6 text-sky-600" />
           </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 min-h-[500px]">
        {activeTab === 'bookings' && (
          <div className="p-6">
            <h3 className="font-serif font-bold text-xl mb-6 text-slate-800">Recent Reservations</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-bold text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-2">Client</th>
                    <th className="py-3 px-2">Service</th>
                    <th className="py-3 px-2">Date & Time</th>
                    <th className="py-3 px-2">Status</th>
                    <th className="py-3 px-2">Payment</th>
                    <th className="py-3 px-2 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {bookings.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(b => (
                    <tr key={b.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-2 font-medium text-slate-900">{b.customerName}</td>
                      <td className="py-3 px-2 text-slate-600">{b.serviceName}</td>
                      <td className="py-3 px-2 text-slate-600">{b.date} <span className="text-slate-300">|</span> {b.timeSlot}</td>
                      <td className="py-3 px-2">
                        {/* Vibrant Status Badges */}
                        <span className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wide border ${
                          b.status === 'confirmed' ? 'bg-emerald-600 text-white border-emerald-600' : 
                          b.status === 'cancelled' ? 'bg-rose-600 text-white border-rose-600' : 
                          'bg-slate-400 text-white border-slate-400'
                        }`}>
                          {b.status}
                        </span>
                      </td>
                      <td className="py-3 px-2">
                        {b.paymentStatus === 'paid' ? (
                          <span className="text-emerald-600 font-bold text-[10px] uppercase">Paid</span>
                        ) : (
                          <span className="text-slate-400 font-bold text-[10px] uppercase">Pending</span>
                        )}
                      </td>
                      <td className="py-3 px-2 text-right">
                        {b.status === 'confirmed' && (
                           <button onClick={() => { updateBookingStatus(b.id, 'cancelled'); refreshData(); }} className="text-rose-600 hover:text-rose-800 text-xs font-bold hover:underline">Cancel</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'calendar' && (
          <div className="flex h-[700px]">
             {/* Main Calendar Grid */}
             <div className="flex-1 p-6 border-r border-slate-200 overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                   <h3 className="font-serif font-bold text-xl text-slate-800">
                     {viewDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                   </h3>
                   <div className="flex gap-2">
                      <button onClick={() => setViewDate(new Date(viewDate.setMonth(viewDate.getMonth() - 1)))} className="p-2 hover:bg-slate-100 rounded text-slate-600"><ChevronLeftIcon /></button>
                      <button onClick={() => setViewDate(new Date(viewDate.setMonth(viewDate.getMonth() + 1)))} className="p-2 hover:bg-slate-100 rounded text-slate-600"><ChevronRightIcon /></button>
                   </div>
                </div>
                <div className="grid grid-cols-7 gap-px bg-slate-200 border border-slate-200 rounded-lg overflow-hidden">
                   {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
                     <div key={d} className="bg-slate-50 p-3 text-center text-xs font-bold text-slate-500 uppercase tracking-wide">{d}</div>
                   ))}
                   {renderCalendar()}
                </div>
             </div>
             
             {/* Sidebar Detail */}
             <div className="w-80 bg-slate-50 p-6 overflow-y-auto">
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-4 border-b border-slate-200 pb-2 flex justify-between items-center">
                  <span>{selectedCalendarDate ? new Date(selectedCalendarDate).toDateString() : 'Select a date'}</span>
                  {selectedCalendarDate && (
                    <span className="text-[10px] bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full">
                       {bookings.filter(b => b.date === selectedCalendarDate && b.status !== 'cancelled').length} Bookings
                    </span>
                  )}
                </h4>
                {selectedCalendarDate ? (
                  <div className="space-y-3">
                    {bookings.filter(b => b.date === selectedCalendarDate && b.status !== 'cancelled')
                      .sort((a,b) => a.timeSlot.localeCompare(b.timeSlot))
                      .map(b => (
                        <div key={b.id} className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                           <div className="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500"></div>
                           <div className="flex justify-between items-start mb-2 pl-2">
                              <span className="font-bold text-slate-900 text-sm flex items-center gap-1">
                                <ClockIcon className="w-3 h-3 text-slate-400" /> {b.timeSlot}
                              </span>
                              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">${b.price}</span>
                           </div>
                           <p className="text-sm font-medium text-slate-800 pl-2">{b.customerName}</p>
                           <p className="text-xs text-slate-500 pl-2">{b.serviceName}</p>
                           <div className="mt-2 pl-2 border-t border-slate-50 pt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                             <button onClick={() => { updateBookingStatus(b.id, 'cancelled'); refreshData(); }} className="text-rose-500 text-xs font-bold hover:underline">Cancel Booking</button>
                           </div>
                        </div>
                      ))}
                    {bookings.filter(b => b.date === selectedCalendarDate && b.status !== 'cancelled').length === 0 && (
                      <p className="text-slate-400 text-sm italic text-center py-10 bg-white rounded border border-slate-100">
                        No bookings scheduled.
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="text-center text-slate-400 mt-20">
                    <CalendarIcon className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p className="text-sm font-medium">Select a date from the grid</p>
                    <p className="text-xs text-slate-400 mt-1">View hourly breakdown</p>
                  </div>
                )}
             </div>
          </div>
        )}

        {activeTab === 'services' && (
           <div className="p-6">
             <div className="flex justify-between items-center mb-6">
                <h3 className="font-serif font-bold text-xl text-slate-800">Service Menu</h3>
                <div className="flex gap-2">
                  {[{k: 'name', l: 'Name'}, {k: 'price', l: 'Price'}, {k: 'duration', l: 'Time'}].map(opt => (
                     <button 
                       key={opt.k}
                       onClick={() => handleSort(opt.k as any)}
                       className={`text-xs px-3 py-1.5 border rounded flex items-center gap-1 transition-colors ${
                         serviceSort.key === opt.k 
                           ? 'bg-slate-800 text-white border-slate-800' 
                           : 'bg-white text-slate-500 border-slate-200 hover:border-slate-400'
                       }`}
                     >
                       {opt.l}
                       {serviceSort.key === opt.k && (
                         <span className="text-[10px]">{serviceSort.direction === 'asc' ? '↑' : '↓'}</span>
                       )}
                     </button>
                  ))}
                </div>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
               {sortedServices.map(s => (
                 <div key={s.id} className="group relative bg-white rounded-lg border border-slate-200 p-6 hover:shadow-lg hover:border-indigo-500/30 transition-all">
                    <div className="flex justify-between items-start mb-2">
                       <h4 className="font-bold text-slate-900 text-lg">{s.name}</h4>
                       <span className="font-serif text-indigo-700 font-bold bg-indigo-50 px-2 py-1 rounded text-sm">${s.price}</span>
                    </div>
                    <p className="text-sm text-slate-500 mb-6 h-10 line-clamp-2 leading-relaxed">{s.description}</p>
                    <div className="flex justify-between items-center text-xs text-slate-400 uppercase tracking-wide border-t border-slate-100 pt-4">
                       <span className="flex items-center gap-1"><ClockIcon className="w-3 h-3" /> {s.duration} MIN</span>
                       <button onClick={() => { if(confirm('Delete?')) { deleteService(s.id); refreshData(); }}} className="text-rose-500 hover:text-rose-700 font-bold hover:bg-rose-50 px-2 py-1 rounded transition-colors">REMOVE</button>
                    </div>
                 </div>
               ))}
               <div 
                 onClick={() => setIsAddingService(true)}
                 className="border-2 border-dashed border-slate-300 rounded-lg p-6 flex flex-col items-center justify-center text-slate-400 hover:border-indigo-500 hover:text-indigo-600 hover:bg-slate-50 cursor-pointer transition-all group"
               >
                  <div className="w-12 h-12 rounded-full bg-white border border-slate-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <PlusIcon className="w-6 h-6" />
                  </div>
                  <span className="text-sm font-bold uppercase tracking-wide">Add New Service</span>
               </div>
             </div>
             
             {isAddingService && (
               <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
                 <div className="bg-white rounded-lg shadow-2xl w-full max-w-md overflow-hidden animate-fade-in">
                    <div className="bg-slate-50 border-b border-slate-200 p-4 flex justify-between items-center">
                      <h4 className="font-bold text-slate-800 flex items-center gap-2"><PlusIcon className="w-4 h-4 text-indigo-600"/> New Service</h4>
                      <button onClick={() => setIsAddingService(false)} className="text-slate-400 hover:text-slate-600 text-lg">&times;</button>
                    </div>
                    <form onSubmit={handleAddService} className="p-6 space-y-4">
                       <div>
                         <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">Service Name</label>
                         <input required className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none" value={newServiceForm.name} onChange={e => setNewServiceForm({...newServiceForm, name: e.target.value})} placeholder="e.g. Luxury Hair Spa" />
                       </div>
                       <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">Price ($)</label>
                            <input required type="number" className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none" value={newServiceForm.price} onChange={e => setNewServiceForm({...newServiceForm, price: Number(e.target.value)})} />
                         </div>
                         <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">Duration (min)</label>
                            <input required type="number" className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none" value={newServiceForm.duration} onChange={e => setNewServiceForm({...newServiceForm, duration: Number(e.target.value)})} />
                         </div>
                       </div>
                       <div>
                         <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">Description</label>
                         <textarea required className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none h-20 resize-none" value={newServiceForm.description} onChange={e => setNewServiceForm({...newServiceForm, description: e.target.value})} placeholder="Brief details about the service..."></textarea>
                       </div>
                       <div className="pt-2">
                         <button type="submit" className="w-full bg-slate-900 text-white font-bold py-3 rounded hover:bg-slate-800 transition-colors shadow-lg">Create Service</button>
                       </div>
                    </form>
                 </div>
               </div>
             )}
           </div>
        )}

        {activeTab === 'inbox' && (
          <div className="p-6">
             <div className="flex justify-between items-center mb-6">
               <h3 className="font-serif font-bold text-xl text-slate-800">Notification Log</h3>
               <div className="flex items-center gap-4">
                   <button 
                     onClick={() => setShowEmailModal(true)}
                     className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold uppercase px-4 py-2 rounded shadow-md transition-colors flex items-center gap-2"
                   >
                     <MailIcon className="w-3 h-3" /> Compose Email
                   </button>
                   <div className="flex gap-2 bg-slate-100 p-1 rounded">
                      {['all', 'confirmation', 'reminder', 'availability'].map(f => (
                        <button 
                          key={f}
                          onClick={() => setNotificationFilter(f as any)}
                          className={`text-[10px] font-bold uppercase px-3 py-1 rounded transition-all ${
                            notificationFilter === f ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                          }`}
                        >
                          {f}
                        </button>
                      ))}
                   </div>
               </div>
             </div>
             <div className="space-y-3">
               {filteredNotifications.length === 0 ? (
                 <div className="text-center py-12 bg-slate-50 rounded border border-slate-100 border-dashed">
                   <MailIcon className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                   <p className="text-slate-400 italic text-sm">No notifications found.</p>
                 </div>
               ) : (
                 filteredNotifications.map((n, idx) => (
                   <div key={idx} className="flex gap-4 p-4 rounded-lg bg-white border border-slate-200 hover:border-slate-300 transition-colors">
                      <div className={`mt-1 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border ${
                        n.type === 'confirmation' ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 
                        n.type === 'availability' ? 'bg-amber-50 border-amber-100 text-amber-600' : 
                        'bg-indigo-50 border-indigo-100 text-indigo-600'
                      }`}>
                         {n.type === 'confirmation' ? <CheckIcon className="w-4 h-4" /> : n.type === 'availability' ? <SparklesIcon className="w-4 h-4" /> : <ClockIcon className="w-4 h-4" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between mb-1">
                           <span className={`text-xs font-bold uppercase tracking-wide ${
                              n.type === 'confirmation' ? 'text-emerald-700' : 
                              n.type === 'availability' ? 'text-amber-700' : 'text-indigo-700'
                           }`}>{n.type}</span>
                           <span className="text-[10px] text-slate-400 flex items-center gap-2">
                             {new Date(n.timestamp).toLocaleString()}
                             {n.deliveryMethod === 'gmail' && <span className="bg-rose-600 text-white px-1.5 py-0.5 rounded font-bold">SMTP</span>}
                           </span>
                        </div>
                        <p className="text-sm text-slate-700 mb-1 font-medium whitespace-pre-wrap">{n.message}</p>
                        <p className="text-xs text-slate-400">To: <span className="font-mono text-slate-500">{n.recipient}</span></p>
                      </div>
                   </div>
                 ))
               )}
             </div>

             {/* Compose Email Modal */}
             {showEmailModal && (
               <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
                 <div className="bg-white rounded-lg shadow-2xl w-full max-w-lg overflow-hidden animate-fade-in">
                    <div className="bg-slate-50 border-b border-slate-200 p-4 flex justify-between items-center">
                      <h4 className="font-bold text-slate-800 flex items-center gap-2"><MailIcon className="w-4 h-4 text-indigo-600"/> Compose Email</h4>
                      <button onClick={() => setShowEmailModal(false)} className="text-slate-400 hover:text-slate-600 text-lg">&times;</button>
                    </div>
                    <form onSubmit={handleSendEmail} className="p-6 space-y-4">
                       <div>
                         <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">Recipient Email</label>
                         <input 
                           required 
                           type="email" 
                           className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none" 
                           value={composeForm.to} 
                           onChange={e => setComposeForm({...composeForm, to: e.target.value})} 
                           placeholder="client@example.com" 
                         />
                       </div>
                       <div>
                         <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">Subject</label>
                         <input 
                           required 
                           type="text" 
                           className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none" 
                           value={composeForm.subject} 
                           onChange={e => setComposeForm({...composeForm, subject: e.target.value})} 
                           placeholder="Important Update" 
                         />
                       </div>
                       <div>
                         <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">Message Body</label>
                         <textarea 
                           required 
                           className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none h-32 resize-none" 
                           value={composeForm.body} 
                           onChange={e => setComposeForm({...composeForm, body: e.target.value})} 
                           placeholder="Type your message here..."
                         ></textarea>
                       </div>
                       <div className="pt-2 flex gap-3">
                         <button type="button" onClick={() => setShowEmailModal(false)} className="flex-1 bg-white border border-slate-300 text-slate-700 font-bold py-3 rounded hover:bg-slate-50 transition-colors">Cancel</button>
                         <button type="submit" className="flex-1 bg-slate-900 text-white font-bold py-3 rounded hover:bg-slate-800 transition-colors shadow-lg">Send Email</button>
                       </div>
                    </form>
                 </div>
               </div>
             )}
          </div>
        )}

        {activeTab === 'settings' && (
           <div className="p-6 max-w-2xl">
              <h3 className="font-serif font-bold text-xl mb-6 text-slate-800">System Configuration</h3>
              
              <div className="space-y-8">
                 <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
                    <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <ClockIcon className="w-4 h-4 text-indigo-600" /> Operational Hours
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                       <div>
                         <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-2">Open</label>
                         <input type="time" className="block w-full border border-slate-300 bg-white rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none" defaultValue={config.openTime} />
                       </div>
                       <div>
                         <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-2">Close</label>
                         <input type="time" className="block w-full border border-slate-300 bg-white rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none" defaultValue={config.closeTime} />
                       </div>
                    </div>
                 </div>

                 <div className="bg-slate-50 p-6 rounded-lg border border-slate-200 relative overflow-hidden">
                    <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <MailIcon className="w-4 h-4 text-indigo-600" /> Email Integration (SMTP)
                    </h4>
                    <div className="absolute top-0 right-0 p-2">
                        <span className="bg-indigo-100 text-indigo-700 text-[10px] font-bold px-2 py-1 rounded uppercase">API Enabled</span>
                    </div>
                    <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                      Configure Gmail API settings to send real emails.
                      <br/><strong>Requirement:</strong> A valid Google Cloud OAuth2 Access Token with <code>gmail.send</code> scope is required.
                    </p>
                    <form onSubmit={saveEmailSettings} className="space-y-4">
                       
                       {/* Redirect URI Display */}
                       <div>
                         <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-2">Authorized Redirect URI</label>
                         <div className="flex gap-2">
                            <input 
                              type="text"
                              className="block w-full border border-slate-300 bg-white text-slate-700 rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none font-mono"
                              value={redirectUri}
                              onChange={(e) => setRedirectUri(e.target.value)}
                            />
                            <button 
                              type="button"
                              onClick={() => {
                                navigator.clipboard.writeText(redirectUri);
                                alert("URI Copied! Add this to your Google Cloud Console.");
                              }}
                              className="bg-white border border-slate-300 text-slate-700 text-xs font-bold uppercase px-3 rounded hover:bg-slate-50 transition-colors"
                            >
                              Copy
                            </button>
                         </div>
                         <p className="text-[10px] text-slate-400 mt-1">
                           Copy this URI into your Google Cloud Console. <br/>
                           <span className="text-amber-600 font-bold">Important:</span> Ensure it matches exactly (e.g., trailing slash or not). You can edit the field above if needed.
                         </p>
                       </div>

                       <div>
                         <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-2">Gmail Address</label>
                         <input 
                            type="email" 
                            className="block w-full border border-slate-300 bg-white rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none" 
                            placeholder="adil.mushtaq67@gmail.com"
                            value={emailForm.gmailAddress}
                            onChange={e => setEmailForm({...emailForm, gmailAddress: e.target.value})}
                         />
                       </div>
                       <div>
                         <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-2">OAuth Access Token</label>
                         <div className="flex gap-2">
                           <input 
                              type="password" 
                              className="block w-full border border-slate-300 bg-white rounded px-3 py-2 text-sm focus:border-indigo-500 outline-none font-mono" 
                              placeholder="Paste access token here..."
                              value={emailForm.gmailAccessToken}
                              onChange={e => setEmailForm({...emailForm, gmailAccessToken: e.target.value})}
                           />
                           <button 
                             type="button" 
                             onClick={handleGoogleAuth}
                             className="bg-white border border-slate-300 text-slate-700 text-xs font-bold uppercase px-4 rounded hover:bg-slate-50 transition-colors whitespace-nowrap"
                           >
                             Get Token
                           </button>
                         </div>
                         <p className="text-[10px] text-slate-400 mt-2">
                           1. Configure Redirect URI above.<br/>
                           2. Click "Get Token" to open Google Auth.<br/>
                           3. Authorize the app.<br/>
                           4. The token will be auto-filled, or copy the <code>access_token</code> from the URL bar.
                         </p>
                       </div>
                       <button type="submit" className="bg-indigo-600 text-white px-6 py-2.5 rounded text-xs font-bold uppercase tracking-wide hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all">
                         Save & Verify Connection
                       </button>
                    </form>
                 </div>
              </div>
           </div>
        )}
      </div>
    </div>
  );
};

const AppContent = ({ role, setRole, notifications }: { role: Role, setRole: (r: Role) => void, notifications: Notification[] }) => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  // Logout handler
  const handleLogout = () => {
    setAdminSession(false);
    setRole('customer');
    navigate('/');
  };

  return (
    <Layout role={role} setRole={setRole} notifications={notifications} onLogout={handleLogout}>
      <Routes>
        <Route path="/" element={<BookingPage />} />
        <Route path="/my-bookings" element={<CustomerDashboard />} />
        <Route path="/login" element={<LoginPage onLogin={setRole} />} />
        <Route 
          path="/admin" 
          element={
            checkAdminSession() ? <AdminDashboard /> : <Navigate to="/login" replace />
          } 
        />
      </Routes>
    </Layout>
  );
};

const App = () => {
  const [role, setRole] = useState<Role>('customer');
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    setNotifications(getNotifications());
    // Restore session if exists
    if (checkAdminSession()) {
      setRole('admin');
    }

    // Poll for notifications every 30s
    const interval = setInterval(() => setNotifications(getNotifications()), 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <HashRouter>
      <AppContent role={role} setRole={setRole} notifications={notifications} />
    </HashRouter>
  );
};

export default App;
